import mido
import time
from pynput.keyboard import Controller

# --- SETTING ---
NAMA_FILE_MIDI = 'midi_雑魚.mid'            # ganti dengan nama midi
NADA_MIDI_AWAL_UNTUK_A = 60               # Middle C = 60

# --- KEYS MAPPING ---
NOTE_TO_KEY_MAP = {
    0: 'a', 1: 'w', 2: 's', 3: 'e', 4: 'd', 5: 'f',
    6: 't', 7: 'g', 8: 'y', 9: 'h', 10: 'u', 11: 'j',
}
KEY_OCTAVE_UP = 'x'
KEY_OCTAVE_DOWN = 'z'

keyboard = Controller()

def main():
    try:
        midi_file = mido.MidiFile(NAMA_FILE_MIDI)
        print(f"Berhasil memuat file MIDI: {NAMA_FILE_MIDI}")
    except Exception as e:
        print(f"ERROR saat memuat file MIDI: {e}")
        return

    print("\nPERSIAPAN SEBELUM MEMULAI:")
    print("1. Buka Perfect Piano & jalankan scrcpy.")
    print("2. Atur oktaf di Perfect Piano ke posisi tengah.")
    print("3. KLIK JENDELA SCRCPY untuk membuatnya aktif.")
    for i in range(5, 0, -1):
        print(f"Memulai dalam {i} detik...", end='\r')
        time.sleep(1)
    print("\nMemainkan lagu...")

    current_app_octave_start_note = NADA_MIDI_AWAL_UNTUK_A

    try:
        # Gunakan .play() agar mido mengonversi ticks -> detik otomatis (memperhitungkan tempo)
        for msg in midi_file.play():   # msg.time di sini adalah detik (float)
            # Tunggu sesuai jeda waktu dari pesan sebelumnya (msg.time sudah detik)
            if msg.time > 0:
                # debug: print(f"--- Jeda {msg.time:.3f} detik ---")
                time.sleep(msg.time)

            # Tangani note on / off
            if msg.type == 'note_on' and msg.velocity > 0:
                note_midi = msg.note

                # Sesuaikan oktaf aplikasi bila perlu
                while note_midi >= current_app_octave_start_note + 12:
                    print(f"Naik oktaf untuk nada {note_midi}")
                    keyboard.press(KEY_OCTAVE_UP); time.sleep(0.01); keyboard.release(KEY_OCTAVE_UP)
                    current_app_octave_start_note += 12
                    time.sleep(0.05)

                while note_midi < current_app_octave_start_note:
                    print(f"Turun oktaf untuk nada {note_midi}")
                    keyboard.press(KEY_OCTAVE_DOWN); time.sleep(0.01); keyboard.release(KEY_OCTAVE_DOWN)
                    current_app_octave_start_note -= 12
                    time.sleep(0.05)

                key_to_action = NOTE_TO_KEY_MAP.get(note_midi % 12)
                if key_to_action:
                    print(f"Tekan  -> Nada: {note_midi}, Tombol: '{key_to_action}'")
                    keyboard.press(key_to_action)
                    # jangan langsung release di sini — tunggu note_off agar sustain chord bekerja

            elif (msg.type == 'note_off') or (msg.type == 'note_on' and msg.velocity == 0):
                note_midi = msg.note
                key_to_action = NOTE_TO_KEY_MAP.get(note_midi % 12)
                if key_to_action:
                    print(f"Lepas  <- Nada: {note_midi}, Tombol: '{key_to_action}'")
                    # Lepas tombol; beri jeda kecil agar perangkat memproses
                    keyboard.release(key_to_action)
                    time.sleep(0.002)

            # bisa tambahkan handling untuk meta messages / tempo changes kalau mau logging

    except KeyboardInterrupt:
        print("\nPlayback dihentikan oleh pengguna.")
    except Exception as e:
        print(f"\nTerjadi kesalahan saat playback: {e}")

    print("Playback selesai.")

if __name__ == "__main__":
    main()
